﻿using Razrabotka.Models;
using Razrabotka.Models.Interface;
using Razrabotka.Models.UsingModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Razrabotka.Presenters
{
    public class Presenter
    {
        IView view; // Ссылки на интерфейсы представления и модели
        IModel model;

        public Presenter(IView view)  // Конструктор, принимающий объект представления и создающий объект модели
        {
            this.view = view;
            model = new Model(view); // Создание объекта модели, передача ему объекта представления

            view.Login = model.GetLogins(); // Инициализация данных в представлении при создании презентера
            view.Emploуees = model.GetEmploуees();
        }

        public void AddEmploуee(Emploуees emploуees) =>  // Метод для добавления нового сотрудника
            model.AddEmploуee(emploуees);  // Вызов метода модели для добавления сотрудника

        public void AddLogin(Login login) => // Метод для добавления новой учетной записи
            model.AddLogin(login, view.Login); // Вызов метода модели для добавления учетной записи

        public List<string> GetRole() => // Метод для получения списка ролей
            model.GetRole(); // Получение списка ролей из модели

        public ObservableCollection<Emploуees> TabNumSearch(int num) =>  // Метод для поиска сотрудников по табельному номеру
            model.TabNumSearch(view.Emploуees, num); // Вызов метода модели для поиска сотрудников по табельному номеру

        public ObservableCollection<Emploуees> FamiliaSearch(string name) => // Метод для поиска сотрудников по фамилии
            model.FamiliaSearch(view.Emploуees, name); // Вызов метода модели для поиска сотрудников по фамилии

        public void SQLCommand(string command, DataGrid dtg) => // Метод для выполнения произвольного SQL-запроса и отображения результата в DataGrid
            model.SQLCommand(command, dtg); // Вызов метода модели для выполнения SQL-запроса и отображения результата в DataGrid
    }
}
