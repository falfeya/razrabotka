﻿using Razrabotka.Models.UsingModel;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;

namespace Razrabotka.DataBase
{
    public class LoginDb
    {
        string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB.accdb;"; // Строка подключения к базе данных
        public List<Login> GetLogins()  // Метод для получения списка учетных записей из базы данных
        {
            List<Login> logins = new List<Login>(); // Создаем список для хранения учетных записей

            OleDbConnection connection = new OleDbConnection(connectionString); // Создаем подключение к базе данных
            connection.Open();
            string query = "SELECT * FROM login"; // SQL-запрос для выборки всех записей из таблицы 'login'
            OleDbCommand command = new OleDbCommand(query, connection); // Создаем команду для выполнения SQL-запроса
            OleDbDataReader reader = command.ExecuteReader(); // Выполняем SQL-запрос и получаем результат в виде объекта OleDbDataReader

            while (reader.Read()) // Обрабатываем каждую запись в результате запроса и добавляем ее в список
            {
                int id = reader.GetInt32(0);
                string userName = reader.GetString(1);
                string password = reader.GetString(2);
                int tabNum = reader.GetInt32(3);
                string role = reader.GetString(4);

                Login login = new Login(id, userName, password, tabNum , role); // Создаем объект учетной записи и добавляем его в список
                logins.Add(login);
            }
            return logins; // Возвращаем список учетных записей
        }

        public void AddLogin(Login login, List<Login> Login) // Метод для добавления новой учетной записи в базу данных
        {
            List<int> id = new List<int>(); // Создаем список для хранения идентификаторов существующих учетных записей
            foreach (var item in Login)  // Заполняем список id значениями из существующих учетных записей
                id.Add(item.Id);
            OleDbConnection connection = new OleDbConnection(connectionString); // Создаем подключение к базе данных
            connection.Open();
            // SQL-запрос для вставки новой записи в таблицу 'Login'
            // Используем максимальное значение id + 1 для новой учетной записи
            string sql = $"INSERT INTO Login VALUES ('{id.Max() + 1}','{login.UserName}', '{login.Password}', '{login.TabNum}', '{login.Role}')";
            OleDbCommand command = new OleDbCommand(sql, connection); // Создаем команду для выполнения SQL-запроса
            command.ExecuteNonQuery(); // Выполняем SQL-запрос для добавления новой учетной записи
            connection.Close(); // Закрываем соединение с базой данных
        } 
    }
}
