﻿using Razrabotka.Models.UsingModel;
using System.Collections.ObjectModel;
using System.Data.OleDb;

namespace Razrabotka.DataBase
{
    public class EmployeeDb
    {
        string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB.accdb;"; // Строка подключения к базе данных
        public ObservableCollection<Emploуees> GetEmployee() // Метод для получения списка сотрудников из базы данных
        {
            ObservableCollection<Emploуees> logins = new ObservableCollection<Emploуees>(); // Создаем коллекцию ObservableCollection для хранения сотрудников

            OleDbConnection connection = new OleDbConnection(connectionString); // Создаем подключение к базе данных
            connection.Open();
            string query = "SELECT * FROM employee"; // SQL-запрос для выборки всех записей из таблицы 'employee'
            OleDbCommand command = new OleDbCommand(query, connection); // Создаем команду для выполнения SQL-запроса
            OleDbDataReader reader = command.ExecuteReader(); // Выполняем SQL-запрос и получаем результат в виде объекта OleDbDataReader

            while (reader.Read()) // Обрабатываем каждую запись в результате запроса и добавляем ее в коллекцию
            {
                int tabNum = reader.GetInt32(0);
                string fio = reader.GetString(1);
                string department = reader.GetString(2);
                string position = reader.GetString(3);

                Emploуees login = new Emploуees(tabNum, fio, department, position); // Создаем объект сотрудника и добавляем его в коллекцию
                logins.Add(login);
            }
            return logins;  // Возвращаем коллекцию сотрудников
        }

        public void AddEmploуee(Emploуees emploуees)  // Метод для добавления нового сотрудника в базу данных
        {
            OleDbConnection connection = new OleDbConnection(connectionString);  // Создаем подключение к базе данных
            connection.Open();
            // SQL-запрос для вставки новой записи в таблицу 'Employee'
            string sql = $"INSERT INTO Employee VALUES ('{emploуees.TabNum}', '{emploуees.FIO}', '{emploуees.Department}', '{emploуees.Position}')";
            OleDbCommand command = new OleDbCommand(sql, connection); // Создаем команду для выполнения SQL-запроса
            command.ExecuteNonQuery(); // Выполняем SQL-запрос для добавления нового сотрудника
            connection.Close(); // Закрываем соединение с базой данных
        }
    }
}
