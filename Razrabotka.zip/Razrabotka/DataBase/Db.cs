﻿using System.Data.OleDb;
using System.Data;
using System.Windows.Controls;

namespace Razrabotka.DataBase
{
    public class Db
    {
        string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB.accdb;"; // Строка подключения к базе данных

        public void SQLCommand(string command, DataGrid dtg) // Метод для выполнения SQL-команды и отображения результата в DataGrid
        {
            using (OleDbConnection connection = new OleDbConnection(connectionString)) // Используем using, чтобы гарантировать освобождение ресурсов
            {
                connection.Open(); // Открываем соединение с базой данных
                OleDbDataAdapter adapter = new OleDbDataAdapter(command, connection); // Создаем адаптер данных для выполнения команды и получения данных
                DataSet ds = new DataSet(); // Создаем DataSet для хранения данных
                adapter.Fill(ds); // Заполняем DataSet данными из базы данных с использованием адаптера
                dtg.ItemsSource = ds.Tables[0].DefaultView; // Устанавливаем источник данных для DataGrid из первой таблицы DataSet
                ds.Dispose(); // Освобождаем ресурсы, вызывая Dispose для DataSet и адаптера
                adapter.Dispose();
            }
        }
    }
}
