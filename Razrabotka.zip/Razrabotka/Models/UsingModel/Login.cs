﻿namespace Razrabotka.Models.UsingModel
{
    public class Login
    {
        //Свойства
        public int Id { get; set; }
        public string? UserName { get; set; }
        public string? Password { get; set; }
        public int? TabNum { get; set; }
        public string? Role { get; set; }

        // Конструктор для создания объекта учетной записи с указанными данными
        public Login(int id, string? userName, string? password, int? tabNum, string? role)
        {
            Id = id;
            UserName = userName;
            Password = password;
            TabNum = tabNum;
            Role = role;
        }

        // Конструктор для создания объекта учетной записи без указания идентификатора
        public Login(string? userName, string? password, int? tabNum, string? role)
        {
            UserName = userName;
            Password = password;
            TabNum = tabNum;
            Role = role;
        }
    }
}
