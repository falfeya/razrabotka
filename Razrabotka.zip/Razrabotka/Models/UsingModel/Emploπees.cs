﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Razrabotka.Models.UsingModel
{
    public class Emploуees : INotifyPropertyChanged
    {
        // Приватные поля для хранения данных сотрудника
        private int tabNum;
        private string? fIO;
        private string? department;
        private string? position;

        public int TabNum  // Свойство для табельного номера сотрудника
        {
            get { return tabNum; }
            set
            {
                tabNum = value; // Устанавливаем новое значение и вызываем метод уведомления об изменении свойства
                OnPropertyChanged("TabNum");
            }
        }
        public string? FIO // Свойство для ФИО сотрудника
        {
            get { return fIO; }
            set
            {
                fIO = value;
                OnPropertyChanged("FIO");
            }
        }
        public string? Department // Свойство для отдела сотрудника
        {
            get { return department; }
            set
            {
                department = value;
                OnPropertyChanged("Department");
            }
        }
        public string? Position // Свойство для должности сотрудника
        {
            get { return position; }
            set
            {
                position = value;
                OnPropertyChanged("Position");
            }
        }

        // Конструктор для инициализации данных сотрудника
        public Emploуees(int tabNum, string? fIO, string? department, string? position)
        {
            TabNum = tabNum;
            FIO = fIO;
            Department = department;
            Position = position;
        }

        public event PropertyChangedEventHandler PropertyChanged;  // Событие, уведомляющее об изменении свойств
        public void OnPropertyChanged([CallerMemberName] string prop = "")  // Метод для вызова события изменения свойства
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
