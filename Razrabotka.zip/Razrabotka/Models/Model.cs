﻿using Razrabotka.DataBase;
using Razrabotka.Models.Interface;
using Razrabotka.Models.UsingModel;
using Razrabotka.View;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Razrabotka.Models
{
    public class Model : IModel
    {   
        IView view; // Ссылка на интерфейс представления для обновления данных в пользовательском интерфейсе
        public Model(IView view) // Конструктор, принимающий объект представления
        {
            this.view = view;
        }

        public List<Login> GetLogins() // Получение списка учетных записей из базы данных
        {
            LoginDb loginDb = new LoginDb(); // Создание объекта для работы с базой данных учетных записей
            var list = loginDb.GetLogins(); // Получение списка учетных записей из базы данных
            return list;  // Возвращение списка учетных записей
        }

        public void AddLogin(Login login, List<Login> Login) // Добавление новой учетной записи в базу данных
        {
            LoginDb loginDb = new LoginDb(); // Создание объекта для работы с базой данных учетных записей
            loginDb.AddLogin(login, Login); // Вызов метода для добавления учетной записи в базу данных
        }

        public ObservableCollection<Emploуees> GetEmploуees() // Получение списка сотрудников из базы данных
        {
            EmployeeDb employeeDb = new EmployeeDb();  // Создание объекта для работы с базой данных сотрудников
            var list = employeeDb.GetEmployee(); // Получение списка сотрудников из базы данных
            return list; // Возвращение списка сотрудников
        }

        public void AddEmploуee(Emploуees emploуees) // Добавление нового сотрудника в базу данных
        {
            EmployeeDb employeeDb = new EmployeeDb();  // Создание объекта для работы с базой данных сотрудников
            employeeDb.AddEmploуee(emploуees); // Вызов метода для добавления сотрудника в базу данных
        }

        public List<string> GetRole() // Получение списка ролей
        {
            List<string> list = new List<string>() // Создание списка ролей
            {
                "Admin",
                "User"
            };
            return list; // Возвращение списка ролей
        }

        // Поиск сотрудников по табельному номеру в коллекции
        public ObservableCollection<Emploуees> TabNumSearch(ObservableCollection<Emploуees> empList, int num)
        {
            ObservableCollection<Emploуees> list = new ObservableCollection<Emploуees>();  // Создание новой коллекции для хранения результатов поиска
            foreach (var item in empList)  // Перебор сотрудников в коллекции и добавление соответствующих записей в новую коллекцию
                if (item.TabNum == num)
                    list.Add(item);
            return list;  // Возвращение коллекции результатов поиска
        }

        // Поиск сотрудников по фамилии в коллекции
        public ObservableCollection<Emploуees> FamiliaSearch(ObservableCollection<Emploуees> empList, string name)
        {
            ObservableCollection<Emploуees> list = new ObservableCollection<Emploуees>();  // Создание новой коллекции для хранения результатов поиска
            foreach (var item in empList)  // Перебор сотрудников в коллекции и добавление соответствующих записей в новую коллекцию
                if (item.FIO.Contains(name))
                    list.Add(item);
            return list;  // Возвращение коллекции результатов поиска
        }

        // Выполнение произвольного SQL-запроса и отображение результата в DataGrid
        public void SQLCommand(string command, DataGrid dtg)
        {
            Db db = new Db(); // Создание объекта для выполнения SQL-запросов
            db.SQLCommand(command, dtg); // Вызов метода для выполнения SQL-запроса и отображения результата в DataGrid
        }
    }
}
