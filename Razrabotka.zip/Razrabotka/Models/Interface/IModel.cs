﻿using Razrabotka.Models.UsingModel;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Controls;

namespace Razrabotka.Models.Interface
{
    public interface IModel
    {
        List<Login> GetLogins(); // Метод для получения списка учетных записей из базы данных
        ObservableCollection<Emploуees> GetEmploуees(); // Метод для получения списка сотрудников из базы данных
        void AddEmploуee(Emploуees emploуees); // Метод для добавления нового сотрудника в базу данных
        List<string> GetRole(); // Метод для получения списка ролей
        void AddLogin(Login login, List<Login> Login);  // Метод для добавления новой учетной записи в базу данных
        ObservableCollection<Emploуees> TabNumSearch(ObservableCollection<Emploуees> empList, int num); // Метод для поиска сотрудника по табельному номеру в коллекции
        ObservableCollection<Emploуees> FamiliaSearch(ObservableCollection<Emploуees> empList, string name);  // Метод для поиска сотрудника по фамилии в коллекции
        void SQLCommand(string command, DataGrid dtg); // Общий метод для выполнения произвольных SQL-запросов и отображения результата в DataGrid
    }
}
