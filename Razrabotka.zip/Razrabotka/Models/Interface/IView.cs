﻿using Razrabotka.Models.UsingModel;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Razrabotka.Models.Interface
{
    public interface IView
    {
        List<Login> Login { get; set; } // Список учетных записей для представления
        ObservableCollection<Emploуees> Emploуees { get; set; }  // Коллекция сотрудников для представления
    }
}
