﻿using Razrabotka.View;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Razrabotka
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e) // Метод OnStartup вызывается при запуске приложения
        {
            // Создание и отображение окна загрузки (Loading) при запуске приложения
            Loading window = new Loading();
            window.Show();
        }
    }
}
