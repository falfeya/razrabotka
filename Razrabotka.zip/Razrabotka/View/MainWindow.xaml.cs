﻿using Razrabotka.Models.Interface;
using Razrabotka.Models.UsingModel;
using Razrabotka.Presenters;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;

namespace Razrabotka.View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IView
    {
        // Свойства для хранения списка учетных записей и коллекции сотрудников
        public List<Login> Login { get; set; } 
        public ObservableCollection<Emploуees> Emploуees { get; set; }


        Presenter presenter; // Объект презентера, обеспечивающий взаимодействие с моделью и представлением
        public MainWindow() // Конструктор класса MainWindow
        {
            InitializeComponent();
            presenter = new Presenter(this); // Инициализация презентера и передача ему ссылки на текущее представление
        }

        private void Entry_Click(object sender, RoutedEventArgs e) // Обработчик события нажатия на кнопку "Вход"
        {
            if (login_txb.Text != "" && password_txb.Password != "") // Проверка наличия введенных данных
            {
                foreach (var item in Login) // Поиск учетной записи по введенному логину и паролю
                {
                    if (login_txb.Text == item.UserName && password_txb.Password == item.Password)
                    {
                        // Создание и отображение окна для работы с данными о сотрудниках
                        Employee employee = new Employee();
                        this.Close();
                        employee.ShowDialog();
                        return;
                    }
                }
                // Вывод сообщения об ошибке в случае, если учетная запись не найдена
                MessageBox.Show("Неправильно введены данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            else
                // Вывод сообщения об ошибке в случае, если не все данные введены
                MessageBox.Show("Данные не введены", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Exit_Click(object sender, RoutedEventArgs e) => // Обработчик события нажатия на кнопку "Выход"
            Application.Current.Shutdown(); // Завершение выполнения приложения
    }
}
