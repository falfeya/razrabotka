﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Razrabotka.Presenters;
using Microsoft.Win32;

namespace Razrabotka.View
{
    /// <summary>
    /// Логика взаимодействия для SQL.xaml
    /// </summary>
    public partial class SQL : Window
    {
        Presenter presenter; // Объект презентера, обеспечивающий взаимодействие с моделью и представлением
        public SQL(Presenter p) // Конструктор класса SQL, принимающий объект презентера
        {
            InitializeComponent();
            presenter = p; // Инициализация презентера
        }

        private void Button_Click(object sender, RoutedEventArgs e) => // Обработчик события нажатия на кнопку "Выполнить запрос"
            presenter.SQLCommand(txb.Text, dtg);  // Вызов метода презентера для выполнения SQL-запроса

        private void Clean_Click(object sender, RoutedEventArgs e) // Обработчик события нажатия на кнопку "Очистить"
        {
            // Очистка текстового поля и установка источника данных для DataGrid в null
            txb.Text = ""; 
            dtg.ItemsSource = null;
        }

        private void Save_Click(object sender, RoutedEventArgs e) // Обработчик события нажатия на кнопку "Сохранить запрос"
        {
            // Открытие диалогового окна для сохранения файла
            SaveFileDialog FD = new SaveFileDialog();
            FD.FileName = "SQL-Запрос";
            FD.Filter = "Текстовый документ (.txt)|.txt|Все файлы (.)| . ";
            // Отображение диалогового окна и получение результата
            bool? result = FD.ShowDialog();
            if (result == true)
            {
                // Запись текста запроса в выбранный файл
                StreamWriter sw = new StreamWriter(FD.FileName);
                string savetext = txb.Text;
                sw.WriteLine(savetext);
                sw.Close();
                // Вывод сообщения о сохранении запроса
                MessageBox.Show("Запрос сохранён", "Сообщение №2");
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e) => // Обработчик события нажатия на кнопку "Назад"
            this.Close(); // Закрытие текущего окна

        private void ReadeRequest_Click(object sender, RoutedEventArgs e) // Обработчик события нажатия на кнопку "Загрузить запрос из файла"
        {
            string connectionString = $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=DB.accdb;"; // Строка подключения к базе данных
            // Открытие диалогового окна для выбора файла
            OpenFileDialog openFileDialog = new OpenFileDialog(); 
            openFileDialog.Filter = "Текстовый документ (*.sql)| *.sql|Все файлы(*.*)| *.* ";
            // Отображение диалогового окна и получение результата
            bool? result = openFileDialog.ShowDialog();
            if (result == true)
            {
                // Создание соединения с базой данных
                OleDbConnection Connection1 = new OleDbConnection(connectionString);
                Connection1.Open();
                OleDbDataAdapter adapter = new OleDbDataAdapter();
                // Чтение содержимого выбранного файла
                StreamReader sr = new StreamReader(openFileDialog.FileName);
                string req = sr.ReadToEnd();
                sr.Close();
                // Выполнение SQL-запроса и заполнение DataGrid результатами
                adapter.SelectCommand = new OleDbCommand(req, Connection1);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                dtg.ItemsSource = ds.Tables[0].DefaultView;
                ds.Dispose();
                adapter.Dispose();
                Connection1.Dispose();
            }
        }
    }
}
