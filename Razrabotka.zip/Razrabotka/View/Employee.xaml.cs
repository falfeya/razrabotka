﻿using Razrabotka.Models.Interface;
using Razrabotka.Models.UsingModel;
using Razrabotka.Presenters;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace Razrabotka.View
{
    /// <summary>
    /// Логика взаимодействия для Employee.xaml
    /// </summary>
    public partial class Employee : Window, IView
    {
        // Свойства для хранения списка учетных записей и коллекции сотрудников
        public List<Login> Login { get; set; }
        public ObservableCollection<Emploуees> Emploуees { get; set; }

        Presenter presenter; // Объект презентера, обеспечивающий взаимодействие с моделью и представлением
        public Employee() // Конструктор окна Employee
        {
            InitializeComponent();
            presenter = new Presenter(this); // Инициализация презентера и передача ему ссылки на текущее представление
            dtg.ItemsSource = Emploуees; // Установка источника данных для DataGrid из коллекции сотрудников
        }

        private void TabNum_Click(object sender, RoutedEventArgs e) // Обработчик события нажатия на кнопку "Поиск по табельному номеру"
        {
            ObservableCollection<Emploуees> empList = new ObservableCollection<Emploуees>(); // Создание коллекции для хранения результатов поиска
            if (TabNum_txb.Text != "")  // Проверка наличия введенного табельного номера
                empList = presenter.TabNumSearch(int.Parse(TabNum_txb.Text)); // Выполнение поиска по табельному номеру и получение результата в коллекцию
            else
            {
                // Вывод сообщения об ошибке в случае, если поле не введено
                MessageBox.Show("Поле не введено", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            // Проверка наличия результатов поиска
            if (empList.Any())
                dtg.ItemsSource = empList; // Установка источника данных для DataGrid из коллекции результатов поиска
            else
                // Вывод сообщения об отсутствии сотрудников с указанным табельным номером
                MessageBox.Show("Работников с таким табельным номером нет", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)  // Обработчик события нажатия на кнопку "Обновить"
        {
            dtg.ItemsSource = Emploуees; // Установка источника данных для DataGrid из исходной коллекции сотрудников
            TabNum_txb.Text = ""; // Очистка полей ввода
            Familia_txb.Text = "";
        }

        private void Exit_Click(object sender, RoutedEventArgs e) => // Обработчик события нажатия на кнопку "Выход"
            Application.Current.Shutdown();  // Завершение выполнения приложения

        private void Failia_Click(object sender, RoutedEventArgs e) // Обработчик события нажатия на кнопку "Поиск по фамилии"
        {
            ObservableCollection<Emploуees> empList = new ObservableCollection<Emploуees>(); // Создание коллекции для хранения результатов поиска
            if (Familia_txb.Text != "") // Проверка наличия введенной фамилии
                empList = presenter.FamiliaSearch(Familia_txb.Text); // Выполнение поиска по фамилии и получение результата в коллекцию
            else
            {
                MessageBox.Show("Поле не введено", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); // Вывод сообщения об ошибке в случае, если поле не введено
                return;
            }
            if (empList.Any()) // Проверка наличия результатов поиска
                dtg.ItemsSource = empList; // Установка источника данных для DataGrid из коллекции результатов поиска
            else // Вывод сообщения об отсутствии сотрудников с указанной фамилией
                MessageBox.Show("Работников с такой фамилией нет", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void AddEmployee_Click(object sender, RoutedEventArgs e) // Обработчик события нажатия на кнопку "Добавить сотрудника"
        {
            AddEmployee addEmployee = new AddEmployee(Emploуees, presenter); // Создание и отображение окна для добавления сотрудника
            addEmployee.ShowDialog();
        }

        private void SQL_Click(object sender, RoutedEventArgs e)  // Обработчик события нажатия на кнопку "SQL-запрос"
        {
            SQL sql = new SQL(presenter); // Создание и отображение окна для выполнения SQL-запроса
            sql.ShowDialog();
        }
    }
}
