﻿using System;
using System.Windows;
using System.Windows.Threading;

namespace Razrabotka.View
{
    public partial class Loading : Window
    {
        private DispatcherTimer timer; // Таймер для обновления прогресс-бара
        private int progressValue; // Значение прогресса
        public Loading()  // Конструктор класса Loading
        {
            InitializeComponent();
            timer = new DispatcherTimer(); // Инициализация таймера
            timer.Interval = TimeSpan.FromMilliseconds(10);
            timer.Tick += Timer_Tick;

            timer.Start();  // Запуск таймера при создании экземпляра класса Loading
        }

        private void Timer_Tick(object sender, EventArgs e) // Обработчик события таймера, обновляющий значение прогресс-бара
        {
            progressValue++; // Увеличение значения прогресса
            progressBar.Value = progressValue; // Установка значения прогресса для прогресс-бара


            if (progressValue >= progressBar.Maximum)  // Проверка завершения загрузки
            {
                timer.Stop();  // Остановка таймера
                MainWindow mw = new MainWindow(); // Создание главного окна
                this.Close(); // Закрытие окна загрузки
                mw.ShowDialog(); // Отображение главного окна
            } 
        }
    }
}
