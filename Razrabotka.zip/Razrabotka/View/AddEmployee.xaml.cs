﻿using Razrabotka.Models.UsingModel;
using Razrabotka.Presenters;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace Razrabotka.View
{
    /// <summary>
    /// Логика взаимодействия для AddEmployee.xaml
    /// </summary>
    public partial class AddEmployee : Window
    {
        ObservableCollection<Emploуees> Emploуees;  // Коллекция сотрудников, переданная из представления
        Presenter presenter;  // Объект презентера, обеспечивающий взаимодействие с моделью и представлением
        public AddEmployee(ObservableCollection<Emploуees> e, Presenter p) // Конструктор окна добавления сотрудника
        {
            InitializeComponent();  // Инициализация коллекции сотрудников и презентера
            Emploуees = e;
            presenter = p;
            Role_cmb.ItemsSource = presenter.GetRole(); // Заполнение выпадающего списка ролей из презентера
        }
        private void AddEmployee_Click(object sender, RoutedEventArgs e) // Обработчик события нажатия на кнопку "Добавить сотрудника"
        {
            // Проверка наличия введенных данных
            if (FIO_txb.Text != "" && Departament_txb.Text != "" && Position_txb.Text != "" && Login_txb.Text != "" && Password_txb.Text != "" && Role_cmb.Text != "")
            {
                List<int> listTabNum = new List<int>(); // Создание списка табельных номеров из существующих сотрудников
                foreach (var item in Emploуees)
                    listTabNum.Add(item.TabNum);
                // Создание новой учетной записи для входа в систему
                Login login = new Login(Login_txb.Text, Password_txb.Text, listTabNum.Max() + 1, Role_cmb.SelectedItem.ToString());
                // Создание нового объекта сотрудника
                Emploуees employee = new Emploуees(listTabNum.Max() + 1, FIO_txb.Text, Departament_txb.Text, Position_txb.Text);
                // Вызов методов презентера для добавления сотрудника и учетной записи в базу данных
                presenter.AddEmploуee(employee);
                presenter.AddLogin(login);
                // Добавление сотрудника в коллекцию для отображения в представлении
                Emploуees.Add(employee);
                // Вывод сообщения об успешном добавлении
                MessageBox.Show("Пользователь добавлен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);   
            }
            else
                // Вывод сообщения об ошибке в случае, если не все данные введены
                MessageBox.Show("Не все данные введены", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Back_Click(object sender, RoutedEventArgs e) => // Обработчик события нажатия на кнопку "Назад"
            this.Close(); // Закрытие окна добавления сотрудника
    }
}
